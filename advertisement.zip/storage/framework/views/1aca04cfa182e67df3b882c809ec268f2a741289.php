<?php if($block): ?>
  <?php
    $title = $block->json_params->title->{$locale} ?? $block->title;
    $brief = $block->json_params->brief->{$locale} ?? $block->brief;
    $content = $block->json_params->content->{$locale} ?? $block->content;
    $image = $block->image != '' ? $block->image : '';
    $image_background = $block->image_background != '' ? $block->image_background : '';
    $url_link = $block->url_link != '' ? $block->url_link : '';
    $url_link_title = $block->json_params->url_link_title->{$locale} ?? $block->url_link_title;
    $style = isset($block->json_params->style) && $block->json_params->style == 'slider-caption-right' ? 'd-none' : '';
    $index = 1;
    
    // Filter all blocks by parent_id
    $block_childs = $blocks->filter(function ($item, $key) use ($block) {
        return $item->parent_id == $block->id;
    });
  ?>

  <section id="slider" class="slider-element" style="background: #2646532b url('<?php echo e($image); ?>') center bottom no-repeat; background-size: 100% auto;">
    <div class="container">
      <div class="row align-items-md-end">
        <div class="col-lg-5 align-self-center flex-column py-6">
          <h1 class="hero-title display-3 fw-bold color font-body"><?php echo e($brief); ?></h1>
          <p class="my-5"><?php echo e($content); ?></p>
        </div>
      </div>
    </div>
    <form class="row mb-0 mb-5 form_ajax" id="template-contactform" name="template-contactform"
        action="<?php echo e(route('frontend.contact.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
      <div class="d-flex justify-content-center p-0">
        <input type="text" id="phone" name="phone" class="required input-intro"
          value="" required placeholder="Nhập SĐT của bạn...">
        <button
          class="button m-0 btn-intro"
          type="submit" id="submit" name="submit" value="submit">
          <span>Đăng ký tư vấn</span>
        </button>
      </div>
      <input type="hidden" name="is_type" value="call_request">
    </form>
  </section>
<?php endif; ?>

<?php /**PATH D:\xampp\htdocs\advertisement\resources\views/frontend/blocks/banner/styles/static.blade.php ENDPATH**/ ?>