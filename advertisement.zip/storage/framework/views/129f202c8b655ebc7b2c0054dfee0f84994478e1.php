
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH D:\xampp\htdocs\advertisement\resources\views/frontend/blocks/main/index.blade.php ENDPATH**/ ?>