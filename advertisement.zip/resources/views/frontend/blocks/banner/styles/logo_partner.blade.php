@if ($block)
  @php
    $title = $block->json_params->title->{$locale} ?? $block->title;
    $brief = $block->json_params->brief->{$locale} ?? $block->brief;
    $content = $block->json_params->content->{$locale} ?? $block->content;
    $block_childs = $blocks->filter(function ($item, $key) use ($block) {
        return $item->parent_id == $block->id;
    });
  @endphp

  <div class="section bg-gray my-0">
    <div class="container clearfix">
      <h3 class="text-center mb-5 block-title">{{ $title }}</h3>
      <div id="oc-clients" class="owl-carousel image-carousel carousel-widget" data-margin="60" data-loop="true" data-nav="false" data-autoplay="5000" data-pagi="false" data-items-xs="2" data-items-sm="3" data-items-md="4" data-items-lg="5" data-items-xl="6">
        @if ($block_childs)
          @foreach ($block_childs as $item)
            @php
              $title_child = $item->json_params->title->{$locale} ?? $item->title;
              $brief_child = $item->json_params->brief->{$locale} ?? $item->brief;
              $content_child = $item->json_params->content->{$locale} ?? $item->content;
              $image_child = $item->image != '' ? $item->image : null;
            @endphp

            <div class="oc-item img-wrap">
              <img class="lazyload" src="{{ asset('images/lazyload.gif') }}" 
              data-src="{{ $image_child }}" alt="{{ $title_child }}">
            </div>
          @endforeach
        @endif
      </div>
    </div>
  </div>
@endif
