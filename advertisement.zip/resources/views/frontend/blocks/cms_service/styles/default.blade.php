@if ($block)
  @php
    $title = $block->json_params->title->{$locale} ?? $block->title;
    $brief = $block->json_params->brief->{$locale} ?? $block->brief;
    $content = $block->json_params->content->{$locale} ?? $block->content;
    $background = $block->image_background != '' ? $block->image_background : '';
    $url_link = $block->url_link != '' ? $block->url_link : '';
    $url_link_title = $block->json_params->url_link_title->{$locale} ?? $block->url_link_title;
    
    // Filter all blocks by parent_id
    $block_childs = $blocks->filter(function ($item, $key) use ($block) {
        return $item->parent_id == $block->id;
    });
    
    $params['status'] = App\Consts::POST_STATUS['active'];
    $params['is_featured'] = true;
    $params['is_type'] = App\Consts::POST_TYPE['service'];
    $rows = App\Http\Services\ContentService::getCmsPost($params)->take(3)->get();
  @endphp

  <div class="section bg-transparent pb-0 my-0">
    <div class="container clearfix">
      <div class="row clearfix">
        <div class="center col-lg-8 offset-lg-2">
          <h3
            class="text-rotater block-title"
            data-separator=","
            data-rotate="fadeInRight"
            data-speed="3500"
          >
            {{ $title }}
            <span class="t-rotate color mt-3 mb-0">
              {{ $brief }}
            </span>
          </h3>
        </div>
        <div class="clear"></div>
        <div class="row clearfix">
          @if ($rows)
            @foreach ($rows as $item)
              @php
                $title_child = $item->json_params->title->{$locale} ?? $item->title;
                $brief_child = $item->json_params->brief->{$locale} ?? $item->brief;
                $content_child = $item->json_params->content->{$locale} ?? $item->content;
                $image_child = $item->image_thumb != '' ? $item->image_thumb : ($item->image != '' ? $item->image : null);
                $date = date('H:i d/m/Y', strtotime($item->created_at));
                // Viet ham xu ly lay slug
                $alias_category = App\Helpers::generateRoute(App\Consts::TAXONOMY['service'], $item->taxonomy_title, $item->taxonomy_id);
                $alias = App\Helpers::generateRoute(App\Consts::TAXONOMY['service'], $title_child, $item->id, 'detail', $item->taxonomy_title);
              @endphp

              <div class="col-lg-4 mb-4">
                <div class="feature-box media-box fbox-bg">
                  <div class="fbox-media">
                    <a href="{{ $alias }}"
                      ><img
                        src="{{ $image_child }}"
                        alt="{{ $title_child }}"
                    /></a>
                  </div>
                  <div class="fbox-content fbox-content-lg">
                    <h3 class="nott ls0 my-3">
                      <a href="{{ $alias }}">{{ $title_child }}</a>
                      <span class="subtitle ls0"
                        >{!! $content_child !!}</span>
                    </h3>
                    <a href="{{ $alias }}" class="btn btn-show btn-dark">Tìm hiểu thêm</a>
                  </div>
                </div>
              </div>
            @endforeach
          @endif
        </div>
      </div>
    </div>
  </div>
@endif
