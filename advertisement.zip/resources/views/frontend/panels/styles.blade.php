<link
  href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700|Montserrat:300,400,500,600,700|Merriweather:300,400,300i,400i&amp;display=swap"
  rel="stylesheet"
  type="text/css"
/>
<link rel="stylesheet" href="{{ asset('themes/frontend/office/css/bootstrap.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ asset('themes/frontend/office/style.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ asset('themes/frontend/office/css/dark.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ asset('themes/frontend/office/css/swiper.css') }}" type="text/css" />

<link rel="stylesheet" href="{{ asset('themes/frontend/office/demos/shop/shop.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ asset('themes/frontend/office/demos/shop/css/fonts.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ asset('themes/frontend/office/css/font-icons.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ asset('themes/frontend/office/css/animate.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ asset('themes/frontend/office/css/magnific-popup.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ asset('themes/frontend/office/css/custom.css') }}" type="text/css" />

<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="{{ asset('themes/frontend/office/fhm-office.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ asset('themes/frontend/office/css/colors5fae.css?color=000000') }}" type="text/css" />
<link rel="stylesheet" href="{{ asset('themes/frontend/office/custom.css') }}" type="text/css" />
